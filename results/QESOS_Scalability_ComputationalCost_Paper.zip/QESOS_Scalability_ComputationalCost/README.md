# QE-SOS — Scalability and Computational Cost

Source: `all_runs.csv` extracted from user-provided `results_scalability.zip`.

## Experimental setup

- Functions: Sphere, Rastrigin
- Dimensions: 10, 30, 50, 100, 200
- Algorithms: SOS, QE-SOS
- Seeds: 42, 84, 126 (three repetitions)
- Population 15; generations 10; NFE 615; QE-SOS 300 quantum calls, 512 shots each

## Main figures (vector PDF + PNG)

1. `figures/Fig1_Scalability_Runtime_Log.pdf`: SOS and QE-SOS wall-clock runtimes versus dimension, log Y-axis, mean ± sample SD.
2. `figures/Fig2_Computational_Cost_Breakdown.pdf`: QE-SOS quantum sampling vs nonquantum time, stacked bars.
3. `figures/Fig3_Computational_Cost_Runtime_Ratio.pdf`: mean ± sample SD of seed-paired QE-SOS/SOS runtime ratios.
4. `figures/Fig4_Computational_Cost_Quantum_Share.pdf`: fraction of QE-SOS runtime spent on quantum sampling.

## Tables

- `tables/Table1_Runtime_Summary_All.csv` and `.tex`: runtime mean, sample SD, quantum fraction, NFE, shots, calls.
- `tables/Table2_Runtime_Ratios.csv` and `.tex`: paired runtime ratio mean, sample SD, median, and ratio of mean runtimes.
- `tables/All_Runs_Source.csv`: 60 raw records for reproducibility.

## Reproduce

```bash
pip install numpy pandas matplotlib
python code/generate_figures.py --input all_runs.csv --output .
```

## Interpretation and limitations

- These results measure *observed wall-clock scaling* over the tested dimensions and software/hardware setup, not asymptotic complexity or a hardware quantum advantage.
- The quantum circuit width is capped at six qubits; quantum calls are constant across dimensions. This explains why runtime can appear flat as D grows, but does not establish scalability beyond tested dimensions.
- Three runs per configuration are too few for reliable inferential statistics; show descriptive mean ± SD and document the machine/backend.
- Runtime ratios are large partly because SOS runtimes are extremely short and subject to measurement noise.
- The timing decomposition is taken from the user's logged quantum_seconds and nonquantum_seconds; it is not independently profiled.
