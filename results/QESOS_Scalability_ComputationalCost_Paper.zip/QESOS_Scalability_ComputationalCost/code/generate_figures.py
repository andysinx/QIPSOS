#!/usr/bin/env python3
"""Reproduce scalability and computational cost figures from all_runs.csv."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':10,'axes.titlesize':10,'pdf.fonttype':42,'ps.fonttype':42,'savefig.bbox':'tight'})
COL={'SOS':'#2474A6','QE-SOS':'#D35400'}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',default='all_runs.csv')
    ap.add_argument('--output',default='.')
    a=ap.parse_args()
    out=Path(a.output); figs=out/'figures'; tables=out/'tables'; figs.mkdir(parents=True,exist_ok=True);tables.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(a.input)
    required={'function','dimension','algorithm','seed','runtime_seconds','quantum_seconds','nonquantum_seconds','nfe','quantum_calls','shots'}
    if missing:=required-set(df.columns):raise ValueError(f'Missing columns: {missing}')
    if (df.runtime_seconds<=0).any():raise ValueError('Nonpositive runtime')
    if not np.allclose(df.quantum_seconds+df.nonquantum_seconds,df.runtime_seconds,rtol=1e-5,atol=1e-5):raise ValueError('Runtime components do not sum to total')
    stats=df.groupby(['function','dimension','algorithm'],as_index=False).agg(n=('seed','size'),runtime_mean=('runtime_seconds','mean'),runtime_sd=('runtime_seconds','std'),quantum_mean=('quantum_seconds','mean'),quantum_sd=('quantum_seconds','std'),nonquantum_mean=('nonquantum_seconds','mean'),nonquantum_sd=('nonquantum_seconds','std'),nfe=('nfe','first'),quantum_calls=('quantum_calls','first'),shots=('shots','first'))
    stats['quantum_fraction_pct']=100*stats.quantum_mean/stats.runtime_mean
    stats.to_csv(tables/'Table1_Runtime_Summary_All.csv',index=False)
    pivot=df.pivot(index=['function','dimension','seed'],columns='algorithm',values='runtime_seconds').dropna(subset=['SOS','QE-SOS'])
    pivot['runtime_ratio']=pivot['QE-SOS']/pivot['SOS']
    paired=pivot.reset_index().groupby(['function','dimension']).agg(n=('runtime_ratio','size'),paired_ratio_mean=('runtime_ratio','mean'),paired_ratio_sd=('runtime_ratio','std'),paired_ratio_median=('runtime_ratio','median')).reset_index()
    mean_ratio=stats.pivot(index=['function','dimension'],columns='algorithm',values='runtime_mean')
    paired['ratio_of_mean_runtimes']=[float(mean_ratio.loc[(r['function'],r['dimension']),'QE-SOS']/mean_ratio.loc[(r['function'],r['dimension']),'SOS']) for _,r in paired.iterrows()]
    paired.to_csv(tables/'Table2_Runtime_Ratios.csv',index=False)
    df.to_csv(tables/'All_Runs_Source.csv',index=False)
    functions=sorted(df['function'].unique()); dims=sorted(df.dimension.unique())
    fig,axs=plt.subplots(1,len(functions),figsize=(5.5*len(functions),3.65),sharey=True,squeeze=False)
    for ax,name in zip(axs[0],functions):
        for alg in ['SOS','QE-SOS']:
            s=stats[(stats['function']==name)&(stats.algorithm==alg)].sort_values('dimension')
            if s.empty:continue
            ax.errorbar(s.dimension,s.runtime_mean,yerr=s.runtime_sd.fillna(0),marker='o',markersize=4,linewidth=1.8,capsize=3,label=alg,color=COL[alg])
        ax.set_yscale('log');ax.set_xticks(dims);ax.set_xlabel('Problem dimension (D)');ax.set_title(name);ax.grid(True,alpha=.22,which='both')
    axs[0,0].set_ylabel('Wall-clock runtime (s, log scale)');axs[0,-1].legend(loc='best',frameon=False)
    fig.tight_layout();fig.savefig(figs/'Fig1_Scalability_Runtime_Log.pdf');fig.savefig(figs/'Fig1_Scalability_Runtime_Log.png',dpi=240);plt.close(fig)
    fig,axs=plt.subplots(1,len(functions),figsize=(5.5*len(functions),3.65),sharey=True,squeeze=False)
    for ax,name in zip(axs[0],functions):
        s=stats[(stats['function']==name)&(stats.algorithm=='QE-SOS')].sort_values('dimension')
        x=np.arange(len(s));ax.bar(x,s.quantum_mean,label='Quantum sampling',color='#D35400')
        ax.bar(x,s.nonquantum_mean,bottom=s.quantum_mean,label='Other work',color='#2474A6')
        ax.set_xticks(x,s.dimension.astype(str));ax.set_xlabel('Problem dimension (D)');ax.set_title(name);ax.grid(axis='y',alpha=.2)
    axs[0,0].set_ylabel('QE-SOS runtime (s)');axs[0,-1].legend(frameon=False,loc='best')
    fig.tight_layout();fig.savefig(figs/'Fig2_Computational_Cost_Breakdown.pdf');fig.savefig(figs/'Fig2_Computational_Cost_Breakdown.png',dpi=240);plt.close(fig)
    fig,axs=plt.subplots(1,len(functions),figsize=(5.5*len(functions),3.65),sharey=True,squeeze=False)
    for ax,name in zip(axs[0],functions):
        s=paired[paired['function']==name].sort_values('dimension')
        ax.errorbar(s.dimension,s.paired_ratio_mean,yerr=s.paired_ratio_sd.fillna(0),marker='s',linewidth=1.8,capsize=3,color='#6C3483')
        ax.set_xticks(dims);ax.set_xlabel('Problem dimension (D)');ax.set_title(name);ax.grid(alpha=.22)
    axs[0,0].set_ylabel('QE-SOS / SOS runtime ratio (paired mean ± SD)')
    fig.tight_layout();fig.savefig(figs/'Fig3_Computational_Cost_Runtime_Ratio.pdf');fig.savefig(figs/'Fig3_Computational_Cost_Runtime_Ratio.png',dpi=240);plt.close(fig)
    fig,axs=plt.subplots(1,len(functions),figsize=(5.5*len(functions),3.65),sharey=True,squeeze=False)
    for ax,name in zip(axs[0],functions):
        s=stats[(stats['function']==name)&(stats.algorithm=='QE-SOS')].sort_values('dimension')
        ax.plot(s.dimension,s.quantum_fraction_pct,marker='o',color='#D35400',linewidth=1.8)
        ax.set_xticks(dims);ax.set_xlabel('Problem dimension (D)');ax.set_title(name);ax.grid(alpha=.22)
    axs[0,0].set_ylabel('Quantum sampling share of QE-SOS runtime (%)')
    fig.tight_layout();fig.savefig(figs/'Fig4_Computational_Cost_Quantum_Share.pdf');fig.savefig(figs/'Fig4_Computational_Cost_Quantum_Share.png',dpi=240);plt.close(fig)
    def latex_table(data,filename,caption,label,fmt):
        with (tables/filename).open('w') as f:
            f.write(data.to_latex(index=False,escape=True,caption=caption,label=label,formatters=fmt,float_format=lambda v:f'{v:.3f}'))
    compact=stats.copy();compact['runtime_s']=compact.apply(lambda r:f"{r.runtime_mean:.4f} ± {r.runtime_sd:.4f}",axis=1)
    compact=compact[['function','dimension','algorithm','n','runtime_s','quantum_fraction_pct']]
    latex_table(compact,'Table1_Runtime_Summary_All.tex','Wall-clock runtime (mean ± SD) over three seeds and fraction attributable to quantum sampling.','tab:runtime_scalability',{'quantum_fraction_pct':lambda v:f'{v:.2f}'})
    latex_table(paired,'Table2_Runtime_Ratios.tex','Paired QE-SOS/SOS wall-clock runtime ratios across matching seeds.','tab:runtime_ratios',{})
    print(f'Validated {len(df)} runs, {len(functions)} functions, {len(dims)} dimensions; output: {out.resolve()}')
if __name__=='__main__':main()
