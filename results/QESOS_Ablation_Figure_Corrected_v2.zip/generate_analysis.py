#!/usr/bin/env python3
"""Reproduce QE-SOS circuit ablation tables, tests and figures from the supplied ZIP.
Usage: python generate_analysis.py /path/to/results_QESOS_circuit_ablation.zip [output_dir]
Dependencies: numpy pandas scipy matplotlib
"""
import sys, zipfile, re
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import wilcoxon
from statsmodels.stats.multitest import multipletests

zip_path=Path(sys.argv[1]) if len(sys.argv)>1 else Path('results_QESOS_circuit_ablation.zip')
out=Path(sys.argv[2]) if len(sys.argv)>2 else Path('QESOS_Circuit_Ablation_Paper')
out.mkdir(parents=True,exist_ok=True)
variants=['full','no_cnot','no_rz','one_layer']
labels={'full':'Full','no_cnot':'No-CNOT','no_rz':'No-RZ','one_layer':'1-Layer'}
problems=['Ackley','Griewank','Michalewicz10','Rastrigin','Rosenbrock','Schwefel12']
with zipfile.ZipFile(zip_path) as z:
    def read_csv(suffix):
        matches=[x for x in z.namelist() if x.endswith('/'+suffix)]
        if len(matches)!=1: raise ValueError((suffix,matches))
        with z.open(matches[0]) as f: return pd.read_csv(f)
    raw=read_csv('all_runs.csv')
    assert len(raw)==480, f'Expected 480 rows, got {len(raw)}'
    assert not raw.duplicated(['problem','variant','run']).any()
    assert set(raw.problem)==set(problems) and set(raw.variant)==set(variants)
    assert (raw.groupby(['problem','variant']).size()==20).all()
    assert (raw.nfe==2415).all() and (raw.quantum_calls==1200).all()
    for problem in problems:
        seeds=[raw[(raw.problem==problem)&(raw.variant==v)].sort_values('run').seed.tolist() for v in variants]
        assert all(s==seeds[0] for s in seeds),f'Seed mismatch: {problem}'
    raw.to_csv(out/'all_runs_verified.csv',index=False)
    s=raw.groupby(['problem','variant'],sort=False).agg(mean=('best','mean'),std=('best','std'),median=('best','median'),minimum=('best','min'),maximum=('best','max'),mean_runtime_seconds=('runtime_seconds','mean'),std_runtime_seconds=('runtime_seconds','std')).reset_index()
    s['problem']=pd.Categorical(s.problem,problems,ordered=True)
    s['variant']=pd.Categorical(s.variant,variants,ordered=True)
    s=s.sort_values(['problem','variant'])
    s.to_csv(out/'table_performance_long.csv',index=False,float_format='%.12g')
    wide=s.assign(mean_std=s.apply(lambda r:f'{r["mean"]:.4g} ± {r["std"]:.3g}',axis=1)).pivot(index='problem',columns='variant',values='mean_std').reindex(index=problems,columns=variants)
    wide.columns=[labels[v] for v in variants]
    wide.to_csv(out/'table_performance_mean_std.csv')
    s.pivot(index='problem',columns='variant',values='mean').reindex(index=problems,columns=variants).to_csv(out/'table_performance_means_numeric.csv')
    s.pivot(index='problem',columns='variant',values='std').reindex(index=problems,columns=variants).to_csv(out/'table_performance_std_numeric.csv')
    s.pivot(index='problem',columns='variant',values='minimum').reindex(index=problems,columns=variants).to_csv(out/'table_best_minima.csv')
    runtime=s[['problem','variant','mean_runtime_seconds','std_runtime_seconds']].copy()
    runtime.to_csv(out/'table_runtime.csv',index=False)
    tests=[]
    for p in problems:
        sub=raw[raw.problem==p]
        base=sub[sub.variant=='full'].sort_values('run')
        for variant in variants[1:]:
            comp=sub[sub.variant==variant].sort_values('run')
            assert np.array_equal(base.run.to_numpy(),comp.run.to_numpy())
            a=base.best.to_numpy(); b=comp.best.to_numpy()
            res=wilcoxon(a,b,alternative='two-sided',zero_method='wilcox',method='auto')
            tests.append(dict(problem=p,comparison=f'Full vs {labels[variant]}',variant=variant,n_pairs=len(a),wilcoxon_statistic=float(res.statistic),p_raw=float(res.pvalue),mean_full=float(a.mean()),mean_comparator=float(b.mean()),mean_difference_full_minus_comparator=float(np.mean(a-b))))
    tests=pd.DataFrame(tests)
    tests['p_holm_global_18']=multipletests(tests.p_raw,method='holm')[1]
    tests['p_holm_within_benchmark_3']=np.nan
    for p in problems:
        ix=tests.problem==p
        tests.loc[ix,'p_holm_within_benchmark_3']=multipletests(tests.loc[ix,'p_raw'],method='holm')[1]
    tests['significant_raw_005']=tests.p_raw<.05
    tests['significant_holm_global_005']=tests.p_holm_global_18<.05
    tests.to_csv(out/'table_wilcoxon_detailed.csv',index=False,float_format='%.12g')
    for col,name in [('p_raw','table_wilcoxon_p_raw.csv'),('p_holm_global_18','table_wilcoxon_p_holm_global.csv'),('p_holm_within_benchmark_3','table_wilcoxon_p_holm_per_benchmark.csv')]:
        t=tests.pivot(index='problem',columns='variant',values=col).reindex(index=problems,columns=variants[1:]);t.columns=[f'Full vs {labels[v]}' for v in variants[1:]];t.to_csv(out/name)
    # Actual NFE-aligned trajectories from individual per-run arrays.
    curves=[]
    for p in problems:
        for v in variants:
            hs=[];ns=[]
            for run in range(20):
                base=f'results_QESOS_circuit_ablation/{p}/{v}/run{run}'
                with z.open(base+'_history.npy') as f: hs.append(np.load(f,allow_pickle=False))
                with z.open(base+'_nfe_history.npy') as f: ns.append(np.load(f,allow_pickle=False))
            H=np.stack(hs); N=np.stack(ns)
            assert H.shape==(20,40), (p,v,H.shape)
            assert np.all(N==N[0]), (p,v)
            for j,nfe in enumerate(N[0]):
                curves.append(dict(problem=p,variant=v,nfe=int(nfe),median=float(np.median(H[:,j])),q25=float(np.quantile(H[:,j],.25)),q75=float(np.quantile(H[:,j],.75)),mean=float(np.mean(H[:,j])),std=float(np.std(H[:,j],ddof=1))))
    curves=pd.DataFrame(curves)
    curves.to_csv(out/'convergence_median_iqr.csv',index=False)

colors={'full':'#1764ab','no_cnot':'#e08c2c','no_rz':'#258c67','one_layer':'#9b5fa9'}
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.23,'savefig.bbox':'tight','pdf.fonttype':42})
def plot(ax,p):
    for v in variants:
        d=curves[(curves.problem==p)&(curves.variant==v)]
        x=d.nfe.to_numpy(); med=d['median'].to_numpy(); q25=d.q25.to_numpy(); q75=d.q75.to_numpy()
        ax.plot(x,med,label=labels[v],color=colors[v],linewidth=1.8)
        ax.fill_between(x,q25,q75,color=colors[v],alpha=.12,linewidth=0)
    ax.set_title(p)
    ax.set_xlabel('Number of function evaluations (NFE)')
    ax.set_ylabel('Best-so-far fitness')
    if p == 'Rosenbrock':
        ax.set_yscale('log')
    elif p in ('Ackley','Griewank','Rastrigin','Schwefel12'):
        ax.set_yscale('symlog',linthresh=1e-7 if p!='Schwefel12' else 1e-3)

def save(fig,name):
    fig.savefig(out/(name+'.pdf'))
    fig.savefig(out/(name+'.png'),dpi=300)
    plt.close(fig)
fig,axes=plt.subplots(2,3,figsize=(15,8.6),constrained_layout=True)
for ax,p in zip(axes.flat,problems): plot(ax,p)
handles,legend_labels=axes.flat[0].get_legend_handles_labels()
fig.legend(handles,legend_labels,loc='outside lower center',ncol=4)
save(fig,'figure_convergence_all_6')
fig,axes=plt.subplots(1,2,figsize=(11,4.5),constrained_layout=True)
for ax,p in zip(axes,['Rastrigin','Schwefel12']):plot(ax,p)
fig.legend(handles,legend_labels,loc='outside lower center',ncol=4)
save(fig,'figure_convergence_rastrigin_schwefel12')
fig,axes=plt.subplots(2,3,figsize=(14,8.5),constrained_layout=True)
for ax,p in zip(axes.flat,problems):
    data=[raw[(raw.problem==p)&(raw.variant==v)].sort_values('run').best.to_numpy() for v in variants]
    bp=ax.boxplot(data,tick_labels=[labels[v] for v in variants],patch_artist=True,showfliers=True)
    for patch,v in zip(bp['boxes'],variants):patch.set_facecolor(colors[v]);patch.set_alpha(.35)
    ax.set_title(p);ax.set_ylabel('Final best fitness');ax.tick_params(axis='x',labelrotation=22)
save(fig,'figure_final_fitness_boxplots')

with open(out/'README_RESULTS.md','w') as f:
    f.write('# QE-SOS Circuit Ablation — reproducible outputs\n\n')
    f.write('Source: supplied ZIP; 6 benchmarks × 4 variants × 20 runs = 480 runs.\n')
    f.write('Every run has 2415 NFE and 1200 quantum sampling calls.\n\n')
    f.write('## Statistics\nWilcoxon signed-rank two-sided, paired by run index and identical seed, SciPy `wilcoxon` with `zero_method="wilcox"`, `method="auto"`. ')
    f.write('Two Holm families provided: global 18 comparisons (recommended conservative primary), and within-benchmark 3 comparisons. ')
    f.write('Pairing by seed does not guarantee identical stochastic trajectories. Non-significant results do not establish equivalence.\n\n')
    f.write('## Figures\nConvergence: median of 20 runs with 25–75% interquartile ribbon, x-axis NFE, log on Rosenbrock; symlog on Ackley, Griewank, Rastrigin, Schwefel12. ')
    f.write('Boxplots: final best fitness for 20 runs. PDF vector and 300 dpi PNG.\n\n')
    f.write('## Files\n- `table_performance_mean_std.csv`: paper-ready summary\n- `table_performance_long.csv`: full numerical summary\n- `table_performance_means_numeric.csv`, `table_performance_std_numeric.csv`, `table_best_minima.csv`\n- `table_wilcoxon_detailed.csv`: test statistic, raw and adjusted p-values\n- `table_wilcoxon_p_raw.csv`, `table_wilcoxon_p_holm_global.csv`, `table_wilcoxon_p_holm_per_benchmark.csv`\n- `convergence_median_iqr.csv`: figure data\n- `table_runtime.csv`\n- `all_runs_verified.csv`\n- figures in PNG and PDF\n- `generate_analysis.py`: full reproduction script\n\n')
    f.write('Reproduce: `python generate_analysis.py input.zip output_directory`\n')
print('min raw p',tests.p_raw.min(),'min Holm global',tests.p_holm_global_18.min())
print(tests[['problem','comparison','p_raw','p_holm_global_18']].to_string(index=False))
print('Output:',out)
