#!/usr/bin/env python3
"""Rebuild convergence figures from the included aggregated 20-run curves.
Usage: python fix_figures.py [directory containing convergence_median_iqr.csv]
"""
import sys
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

out=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
curves=pd.read_csv(out/'convergence_median_iqr.csv')
variants=['full','no_cnot','no_rz','one_layer']
labels={'full':'Full','no_cnot':'No-CNOT','no_rz':'No-RZ','one_layer':'1-Layer'}
colors={'full':'#1764ab','no_cnot':'#e08c2c','no_rz':'#258c67','one_layer':'#9b5fa9'}
problems=['Ackley','Griewank','Michalewicz10','Rastrigin','Rosenbrock','Schwefel12']
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.23,'savefig.bbox':'tight','pdf.fonttype':42})
def plot(ax,p):
    for v in variants:
        d=curves[(curves.problem==p)&(curves.variant==v)].sort_values('nfe')
        x=d.nfe.to_numpy(); med=d['median'].to_numpy(); q25=d.q25.to_numpy(); q75=d.q75.to_numpy()
        ax.plot(x,med,label=labels[v],color=colors[v],linewidth=1.8)
        ax.fill_between(x,q25,q75,color=colors[v],alpha=.12,linewidth=0)
    ax.set_title(p);ax.set_xlabel('Number of function evaluations (NFE)');ax.set_ylabel('Best-so-far fitness')
    if p=='Rosenbrock':
        assert (curves.loc[curves.problem==p,['median','q25','q75']].to_numpy()>0).all(), 'Rosenbrock log requires positive data'
        ax.set_yscale('log')
    elif p in ('Ackley','Griewank','Rastrigin','Schwefel12'):
        ax.set_yscale('symlog',linthresh=1e-7 if p!='Schwefel12' else 1e-3)
def save(fig,name):
    fig.savefig(out/(name+'.pdf'));fig.savefig(out/(name+'.png'),dpi=300);plt.close(fig)
fig,axes=plt.subplots(2,3,figsize=(15,8.6),constrained_layout=True)
for ax,p in zip(axes.flat,problems):plot(ax,p)
handles,leg=axes.flat[0].get_legend_handles_labels()
fig.legend(handles,leg,loc='outside lower center',ncol=4)
save(fig,'figure_convergence_all_6')
fig,axes=plt.subplots(1,2,figsize=(11,4.5),constrained_layout=True)
for ax,p in zip(axes,['Rastrigin','Schwefel12']):plot(ax,p)
fig.legend(handles,leg,loc='outside lower center',ncol=4)
save(fig,'figure_convergence_rastrigin_schwefel12')
print('Regenerated convergence figures; Rosenbrock uses log y-axis.')
