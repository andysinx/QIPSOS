# QE-SOS Circuit Ablation — reproducible outputs

Source: supplied ZIP; 6 benchmarks × 4 variants × 20 runs = 480 runs.
Every run has 2415 NFE and 1200 quantum sampling calls.

## Statistics
Wilcoxon signed-rank two-sided, paired by run index and identical seed, SciPy `wilcoxon` with `zero_method="wilcox"`, `method="auto"`. Two Holm families provided: global 18 comparisons (recommended conservative primary), and within-benchmark 3 comparisons. Pairing by seed does not guarantee identical stochastic trajectories. Non-significant results do not establish equivalence.

## Figures
Convergence: median of 20 runs with 25–75% interquartile ribbon, x-axis NFE, log on Rosenbrock; symlog on Ackley, Griewank, Rastrigin, Schwefel12. Boxplots: final best fitness for 20 runs. PDF vector and 300 dpi PNG.

## Files
- `table_performance_mean_std.csv`: paper-ready summary
- `table_performance_long.csv`: full numerical summary
- `table_performance_means_numeric.csv`, `table_performance_std_numeric.csv`, `table_best_minima.csv`
- `table_wilcoxon_detailed.csv`: test statistic, raw and adjusted p-values
- `table_wilcoxon_p_raw.csv`, `table_wilcoxon_p_holm_global.csv`, `table_wilcoxon_p_holm_per_benchmark.csv`
- `convergence_median_iqr.csv`: figure data
- `table_runtime.csv`
- `all_runs_verified.csv`
- figures in PNG and PDF
- `generate_analysis.py`: full reproduction script

Reproduce: `python generate_analysis.py input.zip output_directory`
