#!/usr/bin/env python3
"""Paper-ready sensitivity figures from the provided summary CSV (mean ± SD, 20 runs)."""
import argparse
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

GROUPS = {
    'depth': ('Circuit depth', 'Number of circuit layers', [('depth_1','1'),('reference','2'),('depth_3','3'),('depth_4','4')]),
    'topology': ('Entanglement topology', 'Entanglement topology', [('reference','Linear'),('topology_ring','Ring'),('topology_full','Full')]),
    'shots': ('Measurement shots', 'Number of measurement shots', [('shots_128','128'),('shots_256','256'),('reference','512')]),
    'qubits': ('Maximum qubits', 'Maximum number of qubits', [('qubits_2','2'),('qubits_4','4'),('reference','6')]),
}
BENCHMARKS=['Ackley','Griewank','Michalewicz10','Rastrigin','Rosenbrock','Schwefel12']

def make(csv_path, output):
    df=pd.read_csv(csv_path)
    required={'problem','configuration','fitness_mean','fitness_sd','n'}
    if not required.issubset(df.columns): raise ValueError(f'Missing columns: {required-set(df.columns)}')
    if df.duplicated(['problem','configuration']).any(): raise ValueError('Duplicate benchmark/configuration entries')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':11,'axes.labelsize':9,'xtick.labelsize':9,'ytick.labelsize':8,'pdf.fonttype':42,'ps.fonttype':42,'savefig.facecolor':'white'})
    output.mkdir(parents=True,exist_ok=True)
    for name,(title,xlabel,items) in GROUPS.items():
        fig,axes=plt.subplots(2,3,figsize=(12.2,6.6),layout='constrained')
        for ax,benchmark in zip(axes.flat,BENCHMARKS):
            xs=np.arange(len(items))
            means=[];stds=[]
            for cfg,label in items:
                d=df[(df.problem==benchmark)&(df.configuration==cfg)]
                if len(d)!=1:raise ValueError(f'Missing {benchmark} / {cfg}')
                means.append(float(d.fitness_mean.iloc[0]));stds.append(float(d.fitness_sd.iloc[0]))
            means=np.array(means);stds=np.array(stds)
            ax.errorbar(xs,means,yerr=stds,fmt='o-',markersize=5,linewidth=1.5,elinewidth=1,capsize=3,color='#225b91',ecolor='#7093b1',zorder=3)
            refidx=[i for i,(cfg,_) in enumerate(items) if cfg=='reference'][0]
            ax.scatter([refidx],[means[refidx]],marker='D',s=38,color='#c4533b',zorder=5,label='Reference')
            ax.set_xticks(xs,[lab for _,lab in items])
            ax.set_xlim(-.35,len(items)-.65)
            ax.set_xlabel(xlabel,labelpad=6)
            ax.set_ylabel('Final best fitness (mean ± SD)')
            ax.set_title(benchmark,fontweight='semibold')
            ax.grid(axis='y',alpha=.22,linewidth=.7)
            ax.spines[['top','right']].set_visible(False)
            ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,3),useMathText=True)
            ax.yaxis.get_offset_text().set_size(8)
            # If variability extends below zero for positive-only objectives, show the actual symmetric SD interval.
            if name=='topology':ax.tick_params(axis='x',labelrotation=0)
        fig.suptitle(f'QE-SOS sensitivity — {title}',fontsize=15,fontweight='semibold')
        fig.savefig(output/f'sensitivity_{name}.pdf',bbox_inches='tight')
        fig.savefig(output/f'sensitivity_{name}.png',dpi=180,bbox_inches='tight')
        plt.close(fig)
    print(f'Created 4 PDF and 4 PNG figures in {output}')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',default='sensitivity_summary.csv');p.add_argument('--output',default='figures');a=p.parse_args()
    make(Path(a.input),Path(a.output))
