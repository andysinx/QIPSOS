# QE-SOS Quantum Circuit Sensitivity — Paper Figures

Four independent publication-oriented figures (PDF vector + PNG preview), one per circuit parameter:
- `sensitivity_depth`: X = number of circuit layers (1,2,3,4)
- `sensitivity_topology`: X = entanglement topology (Linear, Ring, Full)
- `sensitivity_shots`: X = number of measurement shots (128,256,512)
- `sensitivity_qubits`: X = maximum number of qubits (2,4,6)

Every figure has six panels (one for each benchmark). Y = final best fitness, mean ± standard deviation over 20 independent runs. Lower fitness is better. Red diamond = reference (2 layers, linear topology, 512 shots, max 6 qubits). No rank transformations or invented values. Each benchmark has its own Y scale; never compare absolute Y values across different benchmark panels.

Run:
```
pip install pandas numpy matplotlib
python generate_plots.py --input sensitivity_summary.csv --output figures
```

The original experimental results ZIP is not duplicated here; this package includes the derived summary CSV and the exact plotting script.
